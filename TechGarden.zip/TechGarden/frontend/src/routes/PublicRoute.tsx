// import { Navigate } from "react-router-dom";
// import { childrenProp } from "../types/contact";

// export const PublicRoute = ({ children }: childrenProp) => {
//     const token: string = JSON.parse(localStorage.getItem("token") as string)
//     if (!token) {
//         return children;
//     } else {
//         return <Navigate to={"/contact"} />
//     }
// }
