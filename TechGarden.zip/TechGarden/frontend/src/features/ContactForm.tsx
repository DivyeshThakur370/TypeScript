import axios from "axios"
import React, { useRef, useState } from "react"
import { resCreateContact } from "../types/Contact"
import { useNavigate } from "react-router-dom"
import dp from "../../public/dp.jpg"

export const ContactForm = () => {
    const navigate = useNavigate()
    const fileInputRef = useRef<HTMLInputElement | null>(null)
    const [image, setImage] = useState<File | null>(null)
    const [email, setEmail] = useState<string>("")
    const [name, setName] = useState<string>("")
    const [number, setNumber] = useState<string>("")
    const removeImage = () => {
        setImage(null)
        if (fileInputRef.current) {
            fileInputRef.current.value = "" // ← Clear the file input
        }
    }
    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault()
        try {
            const formData = new FormData()
            if (image) {
                formData.append("image", image)
            }
            formData.append("email", email)
            formData.append("name", name)
            formData.append("number", number)
            const res = await axios.post<resCreateContact>(`http://localhost:8080/contact/create`, formData, {
                withCredentials: true,
                headers: {
                    "Content-Type": "multipart/form-data",
                },
            })
            console.log(res.data)
            if (res.data.success) {
                navigate("/contact")
            }
        } catch (error: unknown) {
            console.error(error)
        }
    }
    return (
        <div>
            <div className="min-h-screen flex items-center justify-center bg-gray-100 px-4">
                <div className="bg-white shadow-md rounded-lg p-8 w-full max-w-md">
                    <h2 className="text-2xl font-bold mb-6 text-center text-gray-800">Create Contact</h2>
                    <form className="space-y-4" onSubmit={handleSubmit}>
                        <div>
                            <label className="block mb-1 font-medium text-gray-700">Profile Image</label>
                            <div className="flex items-center space-x-4 bg-gray-50 p-3 rounded-md border border-gray-300">
                                <img
                                    src={image ? URL.createObjectURL(image) : dp}
                                    className="w-12 h-12 object-cover rounded-full border"
                                    alt="Preview"
                                />
                                <input
                                    ref={fileInputRef}
                                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => {
                                        if (e.target.files) {
                                            setImage(e.target.files[0])
                                        }
                                    }}
                                    type="file"
                                    className="flex-1 text-sm text-gray-700 file:mr-4 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-blue-600 file:text-white hover:file:bg-blue-700"
                                />
                                <button
                                    type="button"
                                    className="text-red-500 hover:text-red-700 text-xl transition"
                                    title="Remove image"
                                    onClick={removeImage}
                                >
                                    ❌
                                </button>
                            </div>
                        </div>

                        <div>
                            <label className="block mb-1 font-medium">Email</label>
                            <input
                                onChange={(e) => setEmail(e.target.value)}
                                type="text"
                                className="w-full border border-gray-300 rounded px-4 py-2"
                            />
                        </div>
                        <div>
                            <label className="block mb-1 font-medium">Name</label>
                            <input
                                onChange={(e) => setName(e.target.value)}
                                type="text"
                                className="w-full border border-gray-300 rounded px-4 py-2"
                            />

                        </div>
                        <div>
                            <label className="block mb-1 font-medium">Number</label>
                            <input
                                onChange={(e) => setNumber(e.target.value)}
                                type="text"
                                className="w-full border border-gray-300 rounded px-4 py-2"
                            />

                        </div>
                        <button
                            type="submit"
                            className="w-full bg-blue-600 text-white py-2 rounded hover:bg-blue-700 transition"
                        >
                            Create
                        </button>
                    </form>
                </div>
            </div>
        </div>
    )
}

